﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string filepath = @"C:\Users\aditya_gorti\Desktop\template.xlsx";

           DataTable dt= ReadExcel(filepath, "xlsx");

            List<Model> lstmodel = new List<Model>();

            lstmodel = dt
                        .AsEnumerable()
                        .Select(x => new Model
                        {
                            id=x.Field<double>("id"),
                            name=x.Field<string>("name"),
                            desc=x.Field<string>("desc")

                        }).ToList();

            var jsonstrin = JsonConvert.SerializeObject(lstmodel);
         
        }

        public static DataTable ReadExcel(string fileName, string fileExt)
        {
            string conn = string.Empty;
            DataTable dtexcel = new DataTable();
            if (fileExt.CompareTo(".xls") == 0)
                conn = @"provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + fileName + ";Extended Properties='Excel 8.0;HRD=Yes;IMEX=1';"; //for below excel 2007  
            else
                conn = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + fileName + ";Extended Properties='Excel 12.0;HDR=Yes';"; //for above excel 2007  
            using (OleDbConnection con = new OleDbConnection(conn))
            {
                try
                {
                    OleDbDataAdapter oleAdpt = new OleDbDataAdapter("select * from [Data$]", con); //here we read data from sheet1  
                    oleAdpt.Fill(dtexcel); //fill excel data into dataTable  
                }
                catch(Exception ex)
                {

                }
            }
            return dtexcel;
        }


    }
}
